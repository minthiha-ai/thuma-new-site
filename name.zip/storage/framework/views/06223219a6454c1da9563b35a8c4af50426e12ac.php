<?php $__env->startSection('content'); ?>
    <!-- latest news start -->
			<section class="lines-section pos-rel black-lines section-bg-light-2" data-midnight="black">
				<!-- lines-container start -->
				<div class="lines-container pos-rel no-lines padding-top-bottom-120">
					<!-- container start -->
					<div class="container small">
						<!-- title start -->
						<h2 class="headline-xl text-center padding-bottom-30 js-scrollanim">
							<span class="text-color-black anim-text-fill" data-text="From">From</span>
							<span class="text-color-black anim-text-fill tr-delay-02" data-text="the">the</span>
							<span class="text-color-red anim-text-fill tr-delay-04" data-text="Blog">Blog</span>
						</h2><!-- title end -->

                        <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- blog-entry start -->
						<article class="flex-container flex-align-center padding-top-30">
							<div class="four-columns column-100-100 padding-top-30">
								<a href="post_dont-panic.html" class="d-block hover-box js-pointer-large js-animsition-link">
									<div class="anim-img-scale anim-img-scale_hover js-img-scale">
										<img class="anim-img-scale__inner" src="<?php echo e(asset('uploads/contents/photos/'.$e->photos)); ?>" alt="Post">
									</div>
								</a>
							</div>
							<div class="eight-columns column-100-100 padding-top-30">
								<div class="column-l-margin-40-999 anim-fade js-scrollanim">
									<ul class="list list_row list_margin-30px">
										<li class="list__item">
											<a href="#" class="subhead-xxs text-color-888888 text-hover-to-red js-pointer-small">By: <?php echo e($e->author); ?></a>
										</li>
										<li class="list__item">
											<a href="#" class="subhead-xxs text-color-888888 text-hover-to-red js-pointer-small">In: <?php echo e($e->content_category->name); ?></a>
										</li>
										<li class="list__item">
											<a href="#" class="subhead-xxs text-color-888888 text-hover-to-red js-pointer-small"><?php echo e(\Illuminate\Support\Carbon::parse($e->created_at)->format("Y, F d")); ?></a>
										</li>
									</ul>
									<a href="post_dont-panic.html" class="margin-top-bottom-30 d-block js-pointer-large js-animsition-link">
										<h6 class="headline-xxxs text-color-black">
											<?php echo e($e->title); ?>

										</h6>
									</a>
									<a href="post_dont-panic.html" class="skew-btn js-pointer-large js-animsition-link">
										<span class="skew-btn__box">
											<span class="skew-btn__content text-color-black">Continue reading</span>
											<span class="skew-btn__arrow black"></span>
										</span>
									</a>
								</div>
							</div>
						</article><!-- blog-entry end -->    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div><!-- container end -->
            </section><!-- latest news end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/she/resources/views/frontend/content.blade.php ENDPATH**/ ?>