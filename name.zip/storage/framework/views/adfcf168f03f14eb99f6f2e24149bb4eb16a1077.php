<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="card-header">
      <h4 class="card-title"><div class="text-primayr">Welcome <span class="ft-user"></span></div></h4>
    </div>
    
    <div class="row mb-3" matchHeight ="card">
      <div class="col-xl-4 col-lg-12">
          <div class="card">
              <div class="card-header">
                  <h4 class="card-title">Content</h4>
              </div>
              <div class="card-body">
                  <div class="card-block">
                      <div class="earning-details mb-4 text-center">
                          <h3 class="mb-1"><?php echo e(count($c), false); ?> <i class="ft-layers"></i></h3>
                          <span class="font-medium-1 grey d-block">Total Contents</span>
                      </div>
                      <div class="action-buttons mt-4 mb-1 text-center">
                          <a class="btn btn-sm btn-raised gradient-blackberry py-2 px-4 white mr-2" href="<?php echo e('admin/content', false); ?>">View Contents</a>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thuma/public_html/she/resources/views/admin/index.blade.php ENDPATH**/ ?>