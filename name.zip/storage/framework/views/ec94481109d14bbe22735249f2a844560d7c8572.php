<?php $__env->startSection('style'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('app-assets/file-input/dist/image-uploader.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/pickadate/pickadate.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header" style="padding: 10px;">
                <h2 class="card-title danger" style="display: inline-block;padding-top:10px;">Edit Member Info</h3>
                <a class="btn btn-sm float-right m-1" style="color:white;background:#833ae8;" href="<?php echo e(route('admin.member.index')); ?>">back</a>
                <a class="btn btn-sm btn-danger float-right m-1" href="<?php echo e(url('/admin')); ?>">Dashboard</a>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body m-3">
                <form action="<?php echo e(route('admin.member.update',$m->id)); ?>" method="post" class="form" enctype="multipart/form-data" id="form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Select Profile Picture</label>
                                    <div class="position-relative has-icon-right">
                                        <div class="inputPic" style="padding-top: .5rem;"></div>
                                        <div class="form-control-position">
                                            <i class="ft-image danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Name</label>
                                    <div class="position-relative has-icon-right">
                                        <input type="text" class="form-control" placeholder="Enter your name" name="name" value="<?php echo e($m->name); ?>" required>
                                        <div class="form-control-position">
                                            <i class="ft-user danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Date of Birth</label>
                                    <div class="input-group">
                                        <input type="text" name="dob" class="form-control pickadate-dropdown" value="<?php echo e($m->dob); ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <i class="fa fa-calendar danger" style="cursor: pointer;"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <div class="position-relative has-icon-right">
                                        <input type="email" class="form-control" placeholder="Enter your email" name="email" value="<?php echo e($m->email); ?>" required>
                                        <div class="form-control-position">
                                            <i class="ft-mail danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Education</label>
                                    <div class="position-relative has-icon-right">
                                        <input type="text" class="form-control" name="education" placeholder="Enter educational status" value="<?php echo e($m->education); ?>" required>
                                        <div class="form-control-position">
                                            <i class="ft-star danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Job</label>
                                    <div class="position-relative has-icon-right">
                                        <input type="text" class="form-control" placeholder="Enter your job" name="job" value="<?php echo e($m->job); ?>" required>
                                        <div class="form-control-position">
                                            <i class="ft-github danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Position</label>
                                    <div class="position-relative has-icon-right">
                                        <input type="text" class="form-control" name="position" placeholder="Enter your position at Thuma Organization" value="<?php echo e($m->position); ?>" required>
                                        <div class="form-control-position">
                                            <i class="ft-monitor danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Favourite Quote</label>
                                    <div class="position-relative has-icon-right">
                                        <input type="text" class="form-control" name="description" placeholder="Enter your own quote or favourite quote" value="<?php echo e($m->description); ?>" required>
                                        <div class="form-control-position">
                                            <i class="ft-heart danger"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <input type="submit" class="btn btn-md float-right" style="color:white;background:#833ae8;" value="Edit">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('app-assets/vendors/js/pickadate/picker.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/pickadate/picker.date.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/pickadate/picker.time.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/pickadate/legacy.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/js/pick-a-datetime.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('app-assets/file-input/src/image-uploader.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('app-assets/file-input/dist/image-uploader.min.js')); ?>" type="text/javascript"></script>
    <script>

        document.getElementsByTagName("body")[0].setAttribute("onload", "loadPic()");
        function loadPic() {
            let titleImg = "<?php echo e($m->photo); ?>";
            let titlePath = "<?php echo e(asset('uploads/members/photos/')); ?>";
            let titlePreload = [];

            for (let tmpImg of titleImg.split(',')){
                titlePreload.push({id: tmpImg, src: titlePath +"/"+tmpImg});
            }

            $('.inputPic').imageUploader({
                preloaded: titlePreload,
                imagesInputName: 'photo',
                preloadedInputName: 'old_photo',
                extensions: ['.jpg','.jpeg','.png'],
                mimes: ['image/jpeg','image/png'],
                maxFiles: 1,
                label:'Click to choose title photo( Only landscape photo! )'
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/she/resources/views/admin/members/edit.blade.php ENDPATH**/ ?>